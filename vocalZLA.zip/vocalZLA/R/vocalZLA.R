#' @title vocalZLA
#' @description Analyses the probability of vocalisations undergoing Zipf's Law of Abbreviation
#'
#' @param note Note data
#' @param duration Duration data
#' @param population Population data
#' @param pop Species or population to analyse
#' @param ID Identifiers of individuals
#' @param minimum Minimum number of notes needed to be viable for analysis (default = 5)
#' @param null The number of permutations in the null distribution (default = 1000)
#'
#' @return Kendall's tau statistical analyses
#' @export

vocalZLA <- function(note, duration, population, pop, ID, minimum = 5, null = 1000){

  # Ensure the minimum is logical
  if(minimum < 1){
    stop('minimum is out of range (min = 1)')
  }

  # Builds a data frame from the given information
  data <- data.frame(note,
                    duration,
                    population,
                    ID
                    )

  # Refine just the population we will study
  focalData <- NULL
  focalData <- data[which(data$population == pop),]
  if(is.null(focalData)){
    stop('no individuals with that name in the dataset.')
  }

  # Rearrange data for ease of calculating Zipf's
  fxkCount <- aggregate(rep(1,nrow(focalData)),
                       by = list(focalData$ID, focalData$note),
                       sum)
  fxkDuration <- aggregate(log(focalData$duration),
                          by = list(focalData$ID, focalData$note),
                          mean)
  meanDuration <- aggregate(fxkDuration$x,
                           by = list(fxkDuration$Group.2),
                           mean)

  # Create the new data frame with this information
  vocalDB <- data.frame(paste(fxkCount$Group.1, fxkCount$Group.2, sep = "."),
                       fxkCount$x, fxkDuration$x, fxkCount$Group.1, fxkCount$Group.2,
                       meanDuration$x[match(fxkCount$Group.2, meanDuration$Group.1)])
  colnames(vocalDB) <- c("IDNote","count","logDuration","ID","note","meanDuration")

  vocalDB$indDev <- vocalDB$logDuration - vocalDB$meanDuration

  # Discard note classes that do not appear at least min.ap times across all birds
  if(minimum > 1){
    classRemove <- NULL
    classCount <- aggregate(vocalDB$count,
                           by = list(vocalDB$note),
                           sum)
    classRemove <- classCount$Group.1[which(classCount$x < minimum)]
    vocalDB <- vocalDB[-which(vocalDB$note %in% classRemove),]
    if(dim(vocalDB)[1] == 0){
      stop('minimum too high; no notes remain')
    }
    if(is.null(classRemove)){
      warning('minimum may be too low; no notes removed')
    }
  }

  # Discard individuals that sing a single note
  freqTable <- table(vocalDB$ID)
  uniqueValues <- freqTable[vocalDB$ID] > 1
  vocalDB <- vocalDB[uniqueValues, ]

  # Discard individuals that sing each note only once $ calculate relative note frequency
  classRemove <- NULL
  relative <- NULL
  classCount <- aggregate(vocalDB$count,
                         by = list(vocalDB$note, vocalDB$ID),
                         sum)
  classUnique <- unique(classCount$Group.2)

  for(i in 1:length(classUnique)){
    classSubset <- subset(classCount, Group.2 == classUnique[i])
    length <- nrow(classSubset)
    sum <- sum(classSubset$x)
    for(j in 1:length(classSubset)){
      calc <- classSubset[j]$x / sum
      relative <- append(relative, calc)
    }
    if(length == sum){
      classRemove <- append(classRemove, classSubset)
    }
  }
  vocalDB$relativeNote <- relative
  if(!is.null(classRemove)){
    vocalDB <- vocalDB[-which(vocalDB$ID %in% classRemove$Group.2),]
  }

  # Testing Zipf's using Kendall's tau
  fullPopNotes <- aggregate(vocalDB$count,
                           by = list(vocalDB$meanDuration),
                           sum)
  fpKendall <- cor.test(fullPopNotes$Group.1, fullPopNotes$x,
                       method = "kendall",
                       alternative = "less",
                       exact = FALSE) # Removes error message - cannot compute exact p-value with ties

  # Collect summary statistics
  indivInPop <- length(unique(vocalDB$ID))
  notesPerIndiv <- nrow(vocalDB)/indivInPop

  # Compute the mean Kendall's tau across all birds
  recIDs <- unique(vocalDB$ID)
  recTaus <- NULL
  tauVar <- NULL
  shannonDiversity <- NULL
  options(warn=-1)

  for (i in 1:length(recIDs)){
    # Select an individual
    thisRecData <- vocalDB[which(vocalDB$ID == recIDs[i]),]

    # Get Shannon diversity of repertoire for that note
    noteProp <- thisRecData$count / sum(thisRecData$count)
    shannonDiv <- -sum(noteProp * log(noteProp))
    shannonDiversity <- rbind(shannonDiversity, shannonDiv)

    # If the population has more than one note type and more than one occurance of that note, compute Kendall's tau and add it to the list
    if(nrow(thisRecData) > 1 & length(unique(thisRecData$count)) > 1){
      tau <- cor.test(thisRecData$count, thisRecData$logDuration,
                     method = "kendall",
                     exact = FALSE)
      recTaus <- rbind(recTaus, tau$estimate)
      tauN <- nrow(thisRecData)
      tauVar <- rbind(tauVar,
                          2*(2*tauN+5) / (9*tauN*(tauN-1)))
    }
  }
  options(warn=0)

  # Calculate mean Kendall's tau across all birds
  if(is.null(recTaus)){
    stop('population has either not enough note types (>1), or not enough occurances of any notes (>1)')
  }
  obsMeanRecTaus <- mean(recTaus)
  obsMeanRecTausW <- sum(recTaus/tauVar) / sum(1/tauVar)

  # Compute null distribution
  nullTaus <- NULL
  nullTausW <- NULL
  noteList <- unique(vocalDB$note)
  for (j in 1:null){
    # Scramble duration among notes
    noteMap <- data.frame(noteList,
                         sample(vocalDB$meanDuration[match(noteList, vocalDB$note)]))

    # Assign the mean scrambled durations to each note sung by each bird
    vocalDB$nullDuration <- noteMap[match(vocalDB$note, noteMap[,1]),2] + sign(rnorm(1))*vocalDB$indDev

    # Compute Kendall's tau in the randomised data and add it to the list
    sampleTau <- NULL
    options(warn=-1)
    for (i in 1:length(recIDs)){
      thisRecData <- vocalDB[which(vocalDB$ID == recIDs[i]),]
      if (nrow(thisRecData)>1 & length(unique(thisRecData$count))>1){
        tau <- cor.test(thisRecData$count, thisRecData$nullDuration,
                       method = "kendall",
                       exact = FALSE)
        sampleTau <- rbind(sampleTau, tau$estimate)
      }
    }
    options(warn=0)
    nullTaus <- rbind(nullTaus, mean(sampleTau))
    nullTausW <- rbind(nullTausW, sum(sampleTau/tauVar) / sum(1/tauVar))
  }

  #compute the p-value
  indP <- (1+sum(nullTaus < obsMeanRecTaus))/(1+length(nullTaus))
  indPW <- (1+sum(nullTausW < obsMeanRecTausW))/(1+length(nullTausW))

  # Create empty data frame for results
  zipfsAllPops <- data.frame(population = character(),
                            birds = integer(),
                            note.richness = numeric(),
                            note.diversity = numeric(),
                            concordance = numeric(),
                            p = numeric(),
                            concordance.w = numeric(),
                            p.w = numeric(),
                            pop.concordance = numeric(),
                            pop.p = numeric())

  #add the results to the output table
  zipfsAllPops <- rbind(zipfsAllPops,
                       c(indivInPop,
                         notesPerIndiv,
                         mean(shannonDiversity),
                         obsMeanRecTaus,
                         indP,
                         obsMeanRecTausW,
                         indPW,
                         fpKendall[[4]],
                         fpKendall[[3]]))


  colnames(zipfsAllPops) <- c("individuals","note count","rep diversity","concordance","p","concordance.weight","p.weight","pop.concordance","pop.p")

  return(round(zipfsAllPops, 4))
}
