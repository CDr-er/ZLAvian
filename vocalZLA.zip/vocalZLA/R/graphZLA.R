#' @title graphZLA
#' @description Produces a scatter graph or heat map to visualise data patterns
#'
#' @param note Note data
#' @param duration Duration data
#' @param population Population data
#' @param pop Species or population to analyse
#' @param ID Identifiers of individuals
#' @param minimum Minimum number of notes needed to be viable for analysis (default = 5)
#' @param heatmap true/false (default = FALSE)
#'
#' @return Optimal graphing based on data
#' @import ggplot2
#' @export

graphZLA <- function(note, duration, population, pop, ID, minimum = 5, heatmap = FALSE){

  # Ensure the minimum is logical
  if(minimum < 0){
    stop('minimum is out of range (min = 0)')
  }

  # Builds a data frame from the given information
  data <- data.frame(note,
                    duration,
                    population,
                    ID
                    )

  # Refine just the population we will study
  focalData <- NULL
  focalData <- data[which(data$population == pop),]
  if(is.null(focalData)){
    stop('no individuals with that name in the dataset')
  }

  # Calculate and add the count of notes and exponent of mean log duration
  fxkCount <- aggregate(rep(1, nrow(focalData)),
                       by = list(focalData$ID, focalData$note),
                       sum)
  fxkDuration <- aggregate(log(focalData$duration),
                          by = list(focalData$ID, focalData$note),
                          mean)
  fxkDuration$x <- exp(fxkDuration$x)
  meanDuration <- aggregate(fxkDuration$x,
                           by = list(fxkDuration$Group.2),
                           mean)

  # Create the new data frame with this information
  vocalDB <- data.frame(paste(fxkCount$Group.1, fxkCount$Group.2, sep = "."),
                       fxkCount$x, fxkDuration$x, fxkCount$Group.1, fxkCount$Group.2,
                       meanDuration$x[match(fxkCount$Group.2, meanDuration$Group.1)])
  colnames(vocalDB) <- c("IDNote","count","explogDuration","ID","note","meanDuration")

  # Discard note classes that do not appear at least min.ap times across all birds
  if(minimum > 1){
    classRemove <- NULL
    classCount <- aggregate(vocalDB$count,
                           by = list(vocalDB$note),
                           sum)
    classRemove <- classCount$Group.1[which(classCount$x < minimum)]
    vocalDB <- vocalDB[-which(vocalDB$note %in% classRemove),]
    if(dim(vocalDB)[1] == 0){
      stop('minimum too high; no notes remain')
    }
    if(is.null(classRemove)){
      warning('minimum may be too low; no notes removed')
    }
  }

  # Discard individuals that sing a single note
  freqTable <- table(vocalDB$ID)
  uniqueValues <- freqTable[vocalDB$ID] > 1
  vocalDB <- vocalDB[uniqueValues, ]

  # Discard individuals that sing each note only once & calculate relative note frequency
  classRemove <- NULL
  relative <- NULL
  classCount <- aggregate(vocalDB$count,
                         by = list(vocalDB$note, vocalDB$ID),
                         sum)
  classUnique <- unique(classCount$Group.2)

  for(i in 1:length(classUnique)){
    classSubset <- subset(classCount, Group.2 == classUnique[i])
    length <- nrow(classSubset)
    sum <- sum(classSubset$x)
    for(j in 1:length(classSubset)){
      calc <- classSubset[j]$x / sum
      relative <- append(relative, calc)
    }
    if(length == sum){
      classRemove <- append(classRemove, classSubset)
    }
  }
  vocalDB$relativeNote <- relative
  if(!is.null(classRemove)){
    vocalDB <- vocalDB[-which(vocalDB$ID %in% classRemove$Group.2),]
  }

  # Graphing the data as optimally as possible
  if(isFALSE(heatmap)){
    # Graphically analysing data - Scatter
    ggplot2::ggplot(data = vocalDB,
                    aes(x = explogDuration,
                        y = count)) +
    ggplot2::geom_point(data = vocalDB,
                        aes(colour = ID,
                            alpha = 0.5)) +
    ggplot2::theme_minimal() +
    ggplot2::theme(legend.position = "none") +
    ggplot2::labs(x = "Exponential of mean log duration",
                  y = "Note count")
  }else{
    # Sort notes by duration
    orderedVocal <- vocalDB[order(vocalDB$count),]
    numberMapping <- c(orderedVocal$explogDuration)
    newNumbers <- 1:nrow(orderedVocal)

    orderedVocal$count[orderedVocal$count %in% numberMapping] <- newNumbers

    mDs <- unique(orderedVocal$relativeNote)
    mDs <- mDs[order(mDs)]
    mDmap <- cbind(mDs, 1:length(mDs))
    orderedVocal$durationRank <- mDmap[match(orderedVocal$relativeNote, mDmap[,1]),2]

    # Sort notes by number of notes sang
    orderedVocal$order <- reorder(orderedVocal$ID, -orderedVocal$count)

    # Graphically analysing data - Heatmap
    ggplot2::ggplot(data = orderedVocal,
                    aes(x = order,
                        y = count,
                        fill = durationRank)) +
    ggplot2::geom_tile() +
    ggplot2::labs(x = "individual",
                  y = "note count",
                  fill = "rank of duration") +
    ggplot2::theme(axis.text.x = element_blank(),
                  axis.ticks.x = element_blank(),
                  panel.background = element_blank(),
                  axis.line.y = element_line(colour = "grey")) +
    ggplot2::scale_fill_gradient(low = "#39FF14",
                                high = "#013220",
                                guide = "colorbar")
  }
}
